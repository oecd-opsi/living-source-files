# iot-service-kit
Internet of Things (IoT) Design Kit (cards, maps, 3D printable pieces) for rapid service concept iteration

Website: http://futurice.github.io/iot-service-kit/

Download the kit: https://github.com/futurice/iot-service-kit/archive/master.zip

Background on the kit: http://futurice.com/blog/tales-from-thingscon-berlin-2015

This kit is currently under modification and not yet complete. Check back soon.

Feedback and requests to ricardo.brito@futurice.com and paul.houghton@futurice.com welcome!
Card Set developed by IoT-EPI - European Platforms Initiative
Design for the IoT EPI Challenge 2017, Berlin

http://iot-epi.eu/
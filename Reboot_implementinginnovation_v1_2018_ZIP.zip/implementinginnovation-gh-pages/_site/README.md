Implementing Innovation
=========================

This is the digital version of the printed Manual designed by [Reboot](http://reboot.org). It's running on Jekyll.
